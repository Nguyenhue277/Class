# -*- coding: utf-8 -*-

from . import education_student
from . import education_class
from . import education_ethnicity
